import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import Editor from '@monaco-editor/react';
import { FolderTree, Play, Code2, CheckCircle2, Loader2 } from 'lucide-react';

const BuilderPage = () => {
  const location = useLocation();
  const [activeTab, setActiveTab] = useState<'code' | 'preview'>('code');
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [currentStep, setCurrentStep] = useState(2); // Mock current step

  const mockFiles = {
    'index.html': '<h1>Hello World</h1>',
    'styles.css': 'body { margin: 0; }',
    'script.js': 'console.log("Hello");'
  };

  const steps = [
    {
      title: 'Analyzing prompt',
      description: 'Processing your requirements and planning the structure',
      status: 'completed'
    },
    {
      title: 'Generating file structure',
      description: 'Creating necessary files and directories',
      status: 'in-progress'
    },
    {
      title: 'Creating HTML template',
      description: 'Building the base HTML structure',
      status: 'pending'
    },
    {
      title: 'Adding styles',
      description: 'Implementing CSS and visual design',
      status: 'pending'
    },
    {
      title: 'Implementing functionality',
      description: 'Adding JavaScript and interactive features',
      status: 'pending'
    }
  ];

  return (
    <div className="min-h-screen bg-[#0d1117] text-[#c9d1d9] flex">
      {/* Left Sidebar - Steps */}
      <div className="w-80 bg-[#161b22] p-6 overflow-y-auto border-r border-[#30363d]">
        <h2 className="text-xl font-bold mb-6 text-[#f0f6fc]">Build Progress</h2>
        <div className="space-y-6">
          {steps.map((step, index) => (
            <div
              key={index}
              className="relative"
            >
              {/* Vertical line connecting steps */}
              {index < steps.length - 1 && (
                <div 
                  className={`absolute left-[15px] top-[30px] w-[2px] h-[calc(100%+24px)] 
                    ${step.status === 'completed' ? 'bg-[#238636]' : 'bg-[#30363d]'}`}
                />
              )}
              
              <div className="flex items-start space-x-4">
                <div className="relative z-10">
                  {step.status === 'completed' && (
                    <CheckCircle2 className="w-8 h-8 text-[#238636]" />
                  )}
                  {step.status === 'in-progress' && (
                    <div className="rounded-full bg-[#1f6feb] p-1">
                      <Loader2 className="w-6 h-6 text-white animate-spin" />
                    </div>
                  )}
                  {step.status === 'pending' && (
                    <div className="w-8 h-8 rounded-full border-2 border-[#30363d]" />
                  )}
                </div>
                <div className="flex-1">
                  <h3 className={`font-medium mb-1 ${
                    step.status === 'completed' ? 'text-[#f0f6fc]' :
                    step.status === 'in-progress' ? 'text-[#58a6ff]' :
                    'text-[#8b949e]'
                  }`}>
                    {step.title}
                  </h3>
                  <p className="text-sm text-[#8b949e]">{step.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Tabs */}
        <div className="bg-[#161b22] p-4 flex space-x-4 border-b border-[#30363d]">
          <button
            onClick={() => setActiveTab('code')}
            className={`flex items-center space-x-2 px-4 py-2 rounded ${
              activeTab === 'code'
                ? 'bg-[#238636] text-white'
                : 'text-[#8b949e] hover:text-[#c9d1d9]'
            }`}
          >
            <Code2 className="w-5 h-5" />
            <span>Code</span>
          </button>
          <button
            onClick={() => setActiveTab('preview')}
            className={`flex items-center space-x-2 px-4 py-2 rounded ${
              activeTab === 'preview'
                ? 'bg-[#238636] text-white'
                : 'text-[#8b949e] hover:text-[#c9d1d9]'
            }`}
          >
            <Play className="w-5 h-5" />
            <span>Preview</span>
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 flex">
          {/* File Explorer */}
          <div className="w-64 bg-[#161b22] border-r border-[#30363d] p-4">
            <div className="flex items-center space-x-2 mb-4">
              <FolderTree className="w-5 h-5 text-[#58a6ff]" />
              <h3 className="font-semibold text-[#f0f6fc]">Files</h3>
            </div>
            <div className="space-y-1">
              {Object.keys(mockFiles).map((filename) => (
                <button
                  key={filename}
                  onClick={() => setSelectedFile(filename)}
                  className={`w-full text-left px-3 py-2 rounded text-sm ${
                    selectedFile === filename
                      ? 'bg-[#1f6feb] text-white'
                      : 'text-[#8b949e] hover:bg-[#21262d] hover:text-[#c9d1d9]'
                  }`}
                >
                  {filename}
                </button>
              ))}
            </div>
          </div>

          {/* Editor/Preview */}
          <div className="flex-1 bg-[#0d1117]">
            {activeTab === 'code' && selectedFile ? (
              <Editor
                height="100%"
                defaultLanguage={selectedFile.endsWith('.js') ? 'javascript' : selectedFile.endsWith('.css') ? 'css' : 'html'}
                defaultValue={mockFiles[selectedFile as keyof typeof mockFiles]}
                theme="vs-dark"
                options={{
                  minimap: { enabled: false },
                  fontSize: 14,
                  background: '#0d1117'
                }}
              />
            ) : activeTab === 'preview' ? (
              <div className="w-full h-full flex items-center justify-center text-[#8b949e]">
                Preview will be shown here
              </div>
            ) : (
              <div className="w-full h-full flex items-center justify-center text-[#8b949e]">
                Select a file to view its contents
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BuilderPage;